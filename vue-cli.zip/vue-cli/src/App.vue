<template>
  <div id="app" class="container mt-5">
    <h1>IDShop</h1>
    <p class="animated fadeInRight">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam, sint reprehenderit facilis dolores molestiae maiores tenetur, odio ipsa saepe minus ratione dignissimos provident nam amet illo quis ex, labore consequuntur.
    </p>
    <font-awesome-icon icon="shopping-cart"></font-awesome-icon>
  </div>
</template>

<script>
import { FontAwesomeIcon } from "@fortawesome/vue-fontawesome";

export default {
  name: "App",
  components: {
    FontAwesomeIcon,
  },
};
</script>
